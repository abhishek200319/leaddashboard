<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dashboard_db";
  

$conn = mysqli_connect($servername, $username, $password, $dbname);
if($conn){
//   echo"connection stablished successfully";
}else{
   echo"there was an error". mysqli_connect_error();
}

?>