<?php
include_once 'database-connection.php';
$sql="SELECT * FROM `register` ";
$result=mysqli_query($conn,$sql);

if ($result->num_rows > 0) {
  //$output="<table id='datatable-fixed-col' class='table table-striped table-bordered'>";
   while($row = $result->fetch_assoc()) {
  ?>
   
   <tr>
      <td><?php echo $row['id']; ?></td>
      <td><?php echo $row['fname']; ?></td>
      <td><?php echo $row['email']; ?></td>
      <td><?php echo $row['password']; ?></td>
      <td><?php echo $row['course_detail']; ?></td>
      <td><button type="button" class="btn btn-primary edit-btn" data-toggle="modal" data-target="#exampleModal" data-id=<?Php echo $row['id']; ?>>
    Edit
</button></td>
      <td><button class="btn btn-danger del-btn" data-toggle="modal" data-target="#confirm-modal"  data-id=<?Php echo $row['id']; ?> > Delete</button></td>
   </tr>
<?php  
}
  
}









?>