<?php
  session_start();
  $servername = "localhost";
  $username = "root";
  $password = "";
  $dbname = "dashboard_db";
    

  $conn = mysqli_connect($servername, $username, $password, $dbname);
  if($conn){
  //   echo"connection stablished successfully";
  }else{
     echo"there was an error". mysqli_connect_error();
  }
 
  
  $lemail=$_POST['lemail'];
  
 $lpassword= $_POST['lpassword'];

 
  //email verification
 $sqle="SELECT Name FROM `admin` WHERE email LIKE BINARY '%$lemail%' ";
   $querye= mysqli_query($conn,$sqle);
   $rowe=mysqli_num_rows($querye);
   $detail=mysqli_fetch_row($querye);
   

   //password verification
   $sqlp="SELECT password FROM `admin` WHERE password LIKE BINARY '%$lpassword%' ";
   $queryp= mysqli_query($conn,$sqlp);
   $rowp=mysqli_num_rows($queryp);

if ($rowe==1 && $rowp==0) {
  echo "<div style='text-align:center; background-color:red;'><h3>wrong password!<a href='login.php' style='display:block'>Try-again</h3></a></div>";
  die;
} else {
  $_SESSION["dlogin"]=$detail;
  header("location:/phpproject/leaddashboard/data.php");
}

  /* if($query){
  // echo "<script>alert('matched user')</script>";
    
    if ($row==1) {
   
   header('Refresh: 0, url = /phpproject/AdminLTE-3.2.0/index.html');
    }
   else{
	header('location:User-register.php');
  echo "please register";
   }
}*/

?>



