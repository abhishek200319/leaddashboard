    <!-- Sidebar -->
    <div class="sidebar">
      <!-- Sidebar user (optional) -->
      

      <!-- SidebarSearch Form -->
     

      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
           <li class="nav">
            <a href="data.php" class="nav-link">
                  <!-- <i class="fa fa-building" aria-hidden="true"></i> -->
                  <p>All Leads</p>
            </a>
            <!-- <a href="buyer.php" class="nav-link">
                  <p>Buyer</p>
            </a>
            <a href="seller.php" class="nav-link">
                  <p>Seller</p>
            </a> -->
            <a href="logout.php" class="nav-link">
                  <i class="fa fa-power-off" aria-hidden="true"></i>
                  <p>Logout</p>
            </a>       
        
          </li>
  
        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
