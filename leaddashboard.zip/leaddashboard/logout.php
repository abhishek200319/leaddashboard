<?php
session_unset($_SESSION['dlogin']);
Session_destroy();
header('location:/phpproject/leaddashboard/pages/login/login.php?log');
?>
