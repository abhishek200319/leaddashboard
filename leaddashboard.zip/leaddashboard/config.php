<?php
   define('DB_SERVER', 'localhost');
   define('DB_USERNAME', 'lux_foroz_ims'); //Database user name
   define('DB_PASSWORD', 'MyPassOk@23'); //Database user password
   define('DB_DATABASE', 'leaddashboard'); //Database user name
   $db = mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);
?>