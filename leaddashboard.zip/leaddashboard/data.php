

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>LCBS | Leads</title>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="./plugins/fontawesome-free/css/all.min.css">
  <!-- DataTables -->
  <link rel="stylesheet" href="./plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
  <link rel="stylesheet" href="./plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
  <link rel="stylesheet" href="./plugins/datatables-buttons/css/buttons.bootstrap4.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="./dist/css/adminlte.min.css">

  <style type="text/css">
    [class*=sidebar-dark-] {
    background-color: #1c2c5e !important;
}
#up-success{
    width: 30% !important;
    float: right;
  
  }
  #up-danger{
width: 30% !important;
    float: right;
   
  }
  #successmsg{
    width: 30% !important;
    float: right;
   
  }

  }
  </style>

</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">
  <!-- Navbar -->
 
  <!-- /.navbar -->


  <aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="#" class="brand-link">
      <img src="https://lcbs.edu.in/wp-content/uploads/2021/01/logo.png" alt="Mynd-Fintech" class="brand-image" style="">
      <span class="brand-text font-weight-light" style="visibility: hidden;">A</span>
    </a>
  <!-- Main Sidebar Container -->
<?php include 'nav.php';?>

    <!-- /.sidebar -->
  </aside>




  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>All Leads</h1>

          </div>
        
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <!-- /.card -->

            <div class="card">
              <div class="card-header">
                <!-- <h3 class="card-title">DataTable with default features</h3> -->

                      <div class="alert alert-danger" role="alert" id="up-danger" style="display: none">
  There was some error please try after some time!
</div>
                      <div class="alert alert-success" role="alert" id="up-success" style="display: none">
  data updated successfully
</div>
                      <div class="alert alert-success" role="alert" id="successmsg" style="display: none">
  Data deleted-successfully!
</div>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
  
                <table id="example1" class="table table-bordered table-striped">
                   <thead>
                                <tr>
                                    <th>id</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Password</th>
                                    <th>course_detail</th>
                                     <th>edit-data</th>
                                    <th>delete-data</th>
                                </tr>
                                </thead>

                  <tbody class="tablecontainer">
                 <?php
include_once 'database-connection.php';
$sql="SELECT * FROM `register` ";
$result=mysqli_query($conn,$sql);

if ($result->num_rows > 0) {
  //$output="<table id='datatable-fixed-col' class='table table-striped table-bordered'>";
   while($row = $result->fetch_assoc()) {
  ?>
   
   <tr>
      <td><?php echo $row['id']; ?></td>
      <td><?php echo $row['fname']; ?></td>
      <td><?php echo $row['email']; ?></td>
      <td><?php echo $row['password']; ?></td>
      <td><?php echo $row['course_detail']; ?></td>
      <td><button type="button" class="btn btn-primary edit-btn" data-toggle="modal" data-target="#exampleModal" data-id=<?Php echo $row['id']; ?>>
    Edit
</button></td>
      <td><button class="btn btn-danger del-btn" data-toggle="modal" data-target="#confirm-modal"  data-id=<?Php echo $row['id']; ?> > Delete</button></td>
   </tr>
<?php  
}
  
}









?>

                  </tbody>
                 
                </table>
       
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
         <!-- Modal -->

        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
<div class="modal fade" id="confirm-modal" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
       <div class="mx-4">
        <div>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <h3 aria-hidden="true">&times;</h3>
        </button>
          <h3 class="modal-title text-center text-dark">confirmation</h3>
          <h5 class="modal-title text-center text-dark">Would you like to delete this?</h5>
         

   
                </div>
      </div>

         <div class="modal-footer">
        <button type="button" class="btn btn-danger" id="modal-btn-si">yes</button>
        <button type="button" class="btn btn-primary" id="modal-btn-no">No</button>
      </div>

    </div>
  </div>
</div>



  
  <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="mx-4">
        <div>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <h1 aria-hidden="true">&times;</h1>
        </button>
          <h2 class="modal-title text-center text-danger">Edit student Data</h2>
           <div class="myform">

           </div>

   
                </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        
      </div>
    </div>
  </div>
</div>

  <!-- /.content-wrapper -->
  <footer class="main-footer">
    
  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="./plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="./plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- DataTables  & Plugins -->
<script src="./plugins/datatables/jquery.dataTables.min.js"></script>
<script src="./plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="./plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="./plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
<script src="./plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
<script src="./plugins/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
<script src="./plugins/jszip/jszip.min.js"></script>
<script src="./plugins/pdfmake/pdfmake.min.js"></script>
<script src="./plugins/pdfmake/vfs_fonts.js"></script>
<script src="./plugins/datatables-buttons/js/buttons.html5.min.js"></script>
<script src="./plugins/datatables-buttons/js/buttons.print.min.js"></script>
<script src="./plugins/datatables-buttons/js/buttons.colVis.min.js"></script>
<!-- AdminLTE App -->
<script src="./dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="./dist/js/demo.js"></script>
<!-- Page specific script -->

  <script type="text/javascript">
  $(function () {
    $("#example1").DataTable({
      "responsive": true, "lengthChange": false, "autoWidth": false,
      "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
    }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "responsive": true,
    });
  });
$(document).ready(function(){

  function loadtable(){
  $.ajax({
        url: "fetchdata.php",
         type: "POST",
         success: function(data) {
         $(".tablecontainer").html(data);
         }
    });
  }
  loadtable();
$(document).on("click", ".del-btn", function(){
  var delid=$(this).data('id');
  var elem= this;
 //alert(delid);

$("#modal-btn-si").on("click",function(){
 var confirmation="yes";
  $("#confirm-modal").modal('hide');
//  alert(confirmation);
   $.ajax({
        url: "remove.php",
         type: "POST",
         data: { id:delid },
         success: function(data) {
        if(data==1){
        $(elem).closest('tr').fadeOut();
      
        loadtable();
         $("#successmsg").show("slow").delay(5000).hide("slow");
          }
        }
    }); 
});

$("#modal-btn-no").on("click",function(){
 var confirmation="no";
  $("#confirm-modal").modal('hide');

});


 // console.log("hii");
 



  });
$(document).on("click", ".edit-btn", function(){
  var editid=$(this).data('id');
  var edit= this;
  //alert(editid);
   $.ajax({
        url: "singlerecordfetch.php",
         type: "POST",
         data: { id:editid },
         success: function(data) {
          
          $(".myform").html(data);
          }
        
    });
});
$(document).on("submit", "#updateform", function(e){
  e.preventDefault();
  var eid=$("input[type='number'][name='number']").val();
  var ename=$("input[type='text'][name='name']").val();
  var eemail=$("input[type='email'][name='email']").val();
  var epass=$("input[type='text'][name='password']").val();
  var ecpass=$("input[type='text'][name='confirm-password']").val();
  var ecourse=$("input[type='text'][name='detail']").val();
 //  alert(upid);

   $.ajax({
        url: "update.php",
         type: "POST",
         data:{
          number:eid,
          name:ename,
          email:eemail,
          password:epass,
          confirmpassword:ecpass,
          detail:ecourse
        },
         success: function(data) {
          if (data==1) {

            loadtable();
         $('#exampleModal').modal('toggle'); 

            $("#up-success").show("slow").delay(5000).hide("slow");
          
             setTimeout(function () {
       // alert('Reloading Page');
        location.reload(true);
      }, 6000);
              }
          
          }
        
    }); 

});

// main

});


</script>
</body>
</html>
